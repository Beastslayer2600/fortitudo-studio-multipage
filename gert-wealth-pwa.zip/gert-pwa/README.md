# Gert Wealth — PWA Setup (Add to Home Screen)

Turns fortitudostudios.site into an installable app on Android and iPhone.
No app store. No fees. No waiting for Apple to judge you.

## What's in this package

```
app/manifest.ts          → drop into your repo's app/ folder
public/icon-192.png
public/icon-512.png
public/icon-192-maskable.png
public/icon-512-maskable.png
public/apple-touch-icon.png   → all 5 go into public/
```

## Step 1 — Copy the files

- `app/manifest.ts` → `app/manifest.ts` (Next.js auto-serves this at /manifest.webmanifest)
- All 5 PNGs → your `public/` folder

## Step 2 — Update app/layout.tsx metadata

Replace your current `metadata` export with this (only the new lines are added,
your title/description are unchanged):

```tsx
export const metadata: Metadata = {
  title: "Gert Fourie | Financial Advisor | Liberty Group FSP 2409 | Pretoria",
  description:
    "Calm, structured financial planning that replaces worry with clarity - Pretoria & Gauteng",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Gert Wealth",
  },
  icons: {
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a110d",
};
```

And update the import at the top of layout.tsx:

```tsx
import type { Metadata, Viewport } from "next";
```

## Step 3 — Push

```bash
git add app/manifest.ts app/layout.tsx public/
git commit -m "Add PWA support: installable app with manifest and icons"
git push origin main
```

Vercel deploys automatically. Done.

## Step 4 — Test it

**Android (Chrome):** open the site → ⋮ menu → "Add to Home screen" /
"Install app". Chrome may also show an install banner automatically.

**iPhone (Safari):** open the site → Share button → "Add to Home Screen".
(Apple only allows this from Safari — Chrome on iOS won't offer it.)

The app opens fullscreen with no browser bar, dark theme, gold GF icon.

## Verify (optional but smart)

- Visit https://fortitudostudios.site/manifest.webmanifest — should return JSON
- Chrome DevTools → Application tab → Manifest — no errors, icons visible
- Lighthouse → PWA audit

## Notes

- HTTPS is required for install — Vercel already gives you that.
- This setup does NOT add offline support (service worker). Install works
  without it. If you later want offline caching, `next-pwa` or `serwist`
  can be added — say the word.
- Tell clients about it: "Save my site as an app" is a nice line in a
  WhatsApp follow-up.
